/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exam;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 *
 * @author J2EE26
 */
public class Test {
    public static void main(String[] args) {
        Resource r = new ClassPathResource("com/exam/spring.xml");
        BeanFactory factory= new XmlBeanFactory(r);
        
        A a = (A) factory.getBean("proxy");
        a.m();
    }
}
