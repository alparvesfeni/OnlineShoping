/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.exam;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/**
 *
 * @author J2EE26
 */
public class AdvisorMethodInterceptor implements MethodInterceptor{

    @Override
    public Object invoke(MethodInvocation mi) throws Throwable {
        Object obj;
        System.out.println("Before business logic");
        obj=mi.proceed();//actual business logic
        System.out.println("After business logic");
        return obj;
    }
    
}
